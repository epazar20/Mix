package com.example.leasing;

import com.aspose.words.*;
import com.aspose.words.reporting.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LeasingReportApp {
    public static void main(String[] args) throws Exception {
        // Aspose Words lisansı ayarlanıyor
        License license = new License();
        try {
            license.setLicense("Aspose.Words.lic");
        } catch (Exception e) {
            System.out.println("Aspose lisansı yüklenemedi, deneme modu ile devam ediliyor.");
        }

        Document doc = new Document("src/main/resources/Template.docx");

        String json = new String(Files.readAllBytes(Paths.get("src/main/resources/data.json")));

        JsonDataLoadOptions options = new JsonDataLoadOptions();
        options.setAlwaysGenerateRootObject(true);

        JsonDataSource dataSource = new JsonDataSource(
            new ByteArrayInputStream(json.getBytes()), options
        );

        ReportingEngine engine = new ReportingEngine();
        engine.buildReport(doc, dataSource, "contract");

        doc.save("LeasingRaporu.docx");
        System.out.println("Rapor başarıyla oluşturuldu: LeasingRaporu.docx");
    }
}